/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2011030937
#define HB_VER_CHLID             "bfbb1007aa407bf5ec1ee5ed73f8db52501f7902"
#define HB_VER_LENTRY            "2020-11-03 10:37 UTC+0100 Aleksander Czajczynski (hb fki.pl)"
#define HB_VER_HB_USER_PRGFLAGS  "-l-"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "msvc64"
