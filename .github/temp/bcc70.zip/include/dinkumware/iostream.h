// iostream.h standard header
#ifndef _IOSTREAM_H_
#define _IOSTREAM_H_
#pragma option push -b -a -pc -Vx- -Ve- -w-inl -w-aus -w-sig
#include <iostream>

 #if _HAS_NAMESPACE
using namespace std;
 #endif /* _HAS_NAMESPACE */

#pragma option pop
#endif /* _IOSTREAM_H_ */

/*
 * Copyright (c) 1992-2006 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V5.01:1422 */
