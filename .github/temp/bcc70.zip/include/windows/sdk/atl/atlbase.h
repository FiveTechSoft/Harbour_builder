// CBuilderXE does not include ATL files as we were unable to secure a license
// For C++ ActiveX development you can now use the DAX (Delphi ActiveX) Framework
// Alternately, you may copy the ATL files from an earlier version of C++Builder
//   $(BDS)\include\atl\*.*   --->   $(BDS)\include\windows\sdk\atl
#error You must copy ATL files from an earlier version of BDS [$(BDS)\include\atl\*.*] to use ATL
