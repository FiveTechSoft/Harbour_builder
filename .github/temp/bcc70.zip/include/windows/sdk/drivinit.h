#pragma option push -b -a8 -pc -A- /*P_O_Push*/
//+---------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (C) Microsoft Corporation, 1992-1999.
//
//  File:       drivinit.h
//
//----------------------------------------------------------------------------

// All items moved to wingdi.h


#pragma option pop /*P_O_Pop*/
