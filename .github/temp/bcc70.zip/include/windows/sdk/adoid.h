//-----------------------------------------------------------------------------
// File:		adoid.h
//
// Copyright:	Copyright (c) Microsoft Corporation 
//
// Contents:	ADO Guids.	
//-----------------------------------------------------------------------------

#ifndef _ADOID_H_
#pragma option push -b -a8 -pc -A- /*P_O_Push*/
#define _ADOID_H_
#include "adodef.h"
#include "ADOGuids.h"

#pragma option pop /*P_O_Pop*/
#endif // _ADOID_H_
