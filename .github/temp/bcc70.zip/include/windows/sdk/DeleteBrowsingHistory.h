#pragma option push -b -a8 -pc -A- /*P_O_Push*/


/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0555 */
/* Compiler settings for deletebrowsinghistory.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __deletebrowsinghistory_h__
#define __deletebrowsinghistory_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IDeleteBrowsingHistory_FWD_DEFINED__
#define __IDeleteBrowsingHistory_FWD_DEFINED__
typedef interface IDeleteBrowsingHistory IDeleteBrowsingHistory;
#endif 	/* __IDeleteBrowsingHistory_FWD_DEFINED__ */


/* header files for imported files */
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


/* interface __MIDL_itf_deletebrowsinghistory_0000_0000 */
/* [local] */ 

// {31caf6e4-d6aa-4090-a050-a5ac8972e9ef} 
DEFINE_GUID( CATID_DeleteBrowsingHistory, 0x31caf6e4,0xd6aa,0x4090,0xa0,0x50,0xa5,0xac,0x89,0x72,0xe9,0xef);
EXTERN_C const GUID CATID_DeleteBrowsingHistory;
#define DELETE_BROWSING_HISTORY_HISTORY              0x0001   // Indicates that the History checkbox was selected.
#define DELETE_BROWSING_HISTORY_COOKIES              0x0002   // Indicates that the Cookies checkbox was selected.
#define DELETE_BROWSING_HISTORY_TIF                  0x0004   // Indicates that the Temporary Internet Files checkbox was selected.
#define DELETE_BROWSING_HISTORY_FORMDATA             0x0008   // Indicates that the Form data checkbox was selected.
#define DELETE_BROWSING_HISTORY_PASSWORDS            0x0010   // Indicates that the Passwords checkbox was selected.
#define DELETE_BROWSING_HISTORY_PRESERVEFAVORITES    0x0020   // Indicates that the Preseve Favorite website data checkbox is selected.


extern RPC_IF_HANDLE __MIDL_itf_deletebrowsinghistory_0000_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_deletebrowsinghistory_0000_0000_v0_0_s_ifspec;

#ifndef __IDeleteBrowsingHistory_INTERFACE_DEFINED__
#define __IDeleteBrowsingHistory_INTERFACE_DEFINED__

/* interface IDeleteBrowsingHistory */
/* [object][helpstring][uuid] */ 


EXTERN_C const IID IID_IDeleteBrowsingHistory;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("cf38ed4b-2be7-4461-8b5e-9a466dc82ae3")
    IDeleteBrowsingHistory : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE DeleteBrowsingHistory( 
            DWORD dwFlags) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDeleteBrowsingHistoryVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            __RPC__in IDeleteBrowsingHistory * This,
            /* [in] */ __RPC__in REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            __RPC__in IDeleteBrowsingHistory * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            __RPC__in IDeleteBrowsingHistory * This);
        
        HRESULT ( STDMETHODCALLTYPE *DeleteBrowsingHistory )( 
            __RPC__in IDeleteBrowsingHistory * This,
            DWORD dwFlags);
        
        END_INTERFACE
    } IDeleteBrowsingHistoryVtbl;

    interface IDeleteBrowsingHistory
    {
        CONST_VTBL struct IDeleteBrowsingHistoryVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDeleteBrowsingHistory_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IDeleteBrowsingHistory_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IDeleteBrowsingHistory_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IDeleteBrowsingHistory_DeleteBrowsingHistory(This,dwFlags)	\
    ( (This)->lpVtbl -> DeleteBrowsingHistory(This,dwFlags) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IDeleteBrowsingHistory_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif



#pragma option pop /*P_O_Pop*/
