// -----------------------------------------------------------------------------------
//    wstring.h - support for delphi widestrings in c++
//                (WideString)
// $Rev: 69592 $
//
// Copyright(c) 1995-2011 Embarcadero Technologies, Inc.
// -----------------------------------------------------------------------------------
#ifndef WSTRING_H
#define WSTRING_H

#pragma delphiheader begin

#include <sysmac.h>
#include <dstring.h>
#include <System.Internal.StrHlpr.hpp>

// WideString is a BSTR on Windows
#if defined(_Windows) && !defined(WIDESTRING_NO_BSTR) && !defined(_DELPHI_NEXTGEN)
#define WIDESTRING_IS_BSTR
#endif

//NOTE: sysmac.h defines WIDECHAR_IS_WCHAR when "System::WideChar" == "wchar_t"

namespace System
{
#if !defined(_DELPHI_NEXTGEN)

  class RTL_DELPHIRETURN WideString
  {
  public:
    // the TStringFloatFormat enum is used by FloatToStrF
    enum TStringFloatFormat
    {sffGeneral, sffExponent, sffFixed, sffNumber, sffCurrency};

    // String of specified character
    static WideString StringOfChar(WideChar ch, int count);

    // Delphi style 'Format'
    //
    static WideString Format(const WideString& format,
                      const TVarRec *args, int size);

    // C style 'sprintf' (NOTE: Target buffer is the string)
    //
#if defined(_Windows)    
    WideString& __cdecl         sprintf(const wchar_t* format, ...); // Returns *this
    int         __cdecl          printf(const wchar_t* format, ...); // Returns formatted length
    int         __cdecl         vprintf(const wchar_t* format, va_list); // Returns formatted length

    // Like above, but appends to the string rather than overwrite
    WideString& __cdecl     cat_sprintf(const wchar_t* format, ...); // Returns *this
    int         __cdecl     cat_printf(const wchar_t* format, ...);  // Returns formatted length
    int         __cdecl     cat_vprintf(const wchar_t* format, va_list); // Returns formatted length
#endif    

    static WideString FormatFloat(const WideString& format,
                                             const long double& value);
    static WideString FloatToStrF(long double value,
                                             TStringFloatFormat format,
                                             int precision, int digits);
    static WideString IntToHex(int value, int digits);
    static WideString CurrToStr(Currency value);
    static WideString CurrToStrF(Currency value,
                                            TStringFloatFormat format,
                                            int digits);

    // Constructors
    WideString(): Data(0) {}
    WideString(const char* src);
    WideString(const WideString& src);
    WideString(const WideChar* src, int len);
    WideString(const char* src, int len);
    WideString(const WideChar* src);
#if !defined(WIDECHAR_IS_CHAR16)    
    WideString(const char16_t* src, int numChar16 = -1);
#endif    
    WideString(const char32_t* src, int numChar32 = -1);

#if !defined(WIDECHAR_IS_WCHAR)
    WideString(const wchar_t* src);
    WideString(const wchar_t* src, int len);
    explicit WideString(const wchar_t  src);
#endif

    explicit WideString(const WideChar src);
    explicit WideString(char src);
    explicit WideString(short src);
    explicit WideString(unsigned short);
    explicit WideString(int src);
    explicit WideString(unsigned int);
    explicit WideString(long);
    explicit WideString(unsigned long);
    explicit WideString(__int64);
    explicit WideString(unsigned __int64);
    explicit WideString(float src);
    explicit WideString(double src);
    explicit WideString(long double src);
    WideString(const UnicodeString& src);
#if !defined(ANSISTRING_AS_TEMPLATE)
    WideString(const AnsiString &src): Data(0) {
      System::Internal::Strhlpr::WideFromAnsi(*this, *PRawByteString(&src));
    }
#else
    template <unsigned short codePage>
    WideString(const AnsiStringT<codePage> &src): Data(0) {
      System::Internal::Strhlpr::WideFromAnsi(*this, *PRawByteString(&src));
    }
#endif

    // Destructor
    ~WideString();

    // Assignments
    //
    WideString& operator =(const WideString& rhs);
#ifdef WIDESTRING_IS_BSTR
    WideString& operator =(BSTR rhs);
#else    
    WideString& operator =(const char16_t* rhs);
#endif
    WideString& operator +=(const WideString& rhs);

    // Comparisons
    //
    bool operator ==(const WideString& rhs) const;
    bool operator !=(const WideString& rhs) const;
    bool operator < (const WideString& rhs) const;
    bool operator > (const WideString& rhs) const;
    bool operator <=(const WideString& rhs) const;
    bool operator >=(const WideString& rhs) const;

#ifdef WIDESTRING_IS_BSTR
    bool operator ==(const BSTR w) const;
    bool operator !=(const BSTR w) const;
    bool operator < (const BSTR w) const;
    bool operator > (const BSTR w) const;
    bool operator <=(const BSTR w) const;
    bool operator >=(const BSTR w) const;
#else    
    bool operator ==(const char16_t* w) const;
    bool operator !=(const char16_t* w) const;
    bool operator < (const char16_t* w) const;
    bool operator > (const char16_t* w) const;
    bool operator <=(const char16_t* w) const;
    bool operator >=(const char16_t* w) const;
#endif

    bool operator ==(const char* s) const
    { return operator ==(WideString(s)); }
    bool operator !=(const char* s) const
    { return operator !=(WideString(s)); }
    bool operator < (const char* s) const
    { return operator < (WideString(s)); }
    bool operator > (const char* s) const
    { return operator > (WideString(s)); }
    bool operator <=(const char* s) const
    { return operator <= (WideString(s)); }
    bool operator >=(const char* s) const
    { return operator >= (WideString(s)); }

    // --------------------------------------------------------------------
    // Accessing character at specified index
    // NOTE: To be compatible with Delphi, 'idx' is one-based
    // --------------------------------------------------------------------
    WideChar & operator [](const int idx) { return Data[idx-1]; }
    const WideChar& operator [](const int idx) const { return Data[idx-1]; }

    // Concatenation
    //
    WideString operator +(const WideString& rhs) const;

    // C string operator
    WideChar* c_bstr() const            { return Data; }

    // Read access to raw Data ptr.
    WideChar* data()                    { return Data; }

    // Query attributes of string
    int  Length() const;
    bool IsEmpty() const { return Data == 0; }

    // Modify string
    void Insert(const WideString& str, int index);
    void Delete(int index, int count);
    void SetLength(int newLength);

    int          Pos(const WideString& subStr) const;
    WideString   LowerCase() const;
    WideString   UpperCase() const;
    WideString   Trim() const;
    WideString   TrimLeft() const;
    WideString   TrimRight() const;
    WideString   SubString(int index, int count) const;

    int          ToInt() const;
    int          ToIntDef(int defaultValue) const;
    double       ToDouble() const;

    bool         IsDelimiter(const WideString& delimiters, int index) const;
    bool         IsPathDelimiter(int index) const;
    int          LastDelimiter(const WideString& delimiters) const;
    WideChar*    LastChar() const;

#ifdef WIDESTRING_IS_BSTR
    // The implicit operator BSTR() has been the source of many issues
    // mainly involving the compiler resorting to incorrect pointer
    // conversion/comparisons. For backward compatibility you can - AYOR -
    // enable the operator by defining NO_WIDESTRING_BSTR_OPERATOR_EXPLICIT
# if !defined(NO_WIDESTRING_BSTR_OPERATOR_EXPLICIT)
#   define WIDESTRING_BSTR_OPERATOR_EXPLICIT explicit
# else
#   define WIDESTRING_BSTR_OPERATOR_EXPLICIT
# endif
    WIDESTRING_BSTR_OPERATOR_EXPLICIT
    operator BSTR() const  { return Data; }
#endif

    // Access internal data (Be careful when using!!)
    //
#ifdef WIDESTRING_IS_BSTR
    // these are definitely going away:  we can either act like a BSTR
    // or a Pascal WideString.  the former is what we need.
    // --xmsb (2002-01-24 23:06)
    BSTR* operator& ()
    {
      return &Data;
    }

    // Attach/Detach from BSTR, Empty Object
    //
    void Attach(BSTR src);
    BSTR Detach();
    void Empty();

    // Retrieve copy of data
    //
    static wchar_t* Copy(wchar_t* src);

    wchar_t* Copy() const
    {
      return Copy(Data);
    }

#endif // WIDESTRING_IS_BSTR

    wchar_t* Copy(wchar_t *, int len) const;

    WideString&    swap(WideString& other);

  private:
    // Initialize from a zero-terminated wide string
    void InitStr(const WideChar*, int);
    WideChar* Data;
  };

  inline bool operator ==(const char* str, const WideString& rhs) {
    return rhs.operator==(WideString(str));
  }

  inline bool operator !=(const char* str, const WideString& rhs) {
    return rhs.operator!=(WideString(str));
  }

  inline bool operator < (const char* str, const WideString& rhs) {
    return rhs.operator>(WideString(str));
  }

  inline bool operator > (const char* str, const WideString& rhs) {
    return rhs.operator<(WideString(str));
  }

  inline bool operator <=(const char* str, const WideString& rhs) {
    return rhs.operator>=(WideString(str));
  }

  inline bool operator >=(const char* str, const WideString& rhs) {
    return rhs.operator<=(WideString(str));
  }


#ifdef WIDESTRING_IS_BSTR
  bool operator ==(const BSTR w, const WideString& rhs);
  bool operator !=(const BSTR w, const WideString& rhs);
  bool operator < (const BSTR w, const WideString& rhs);
  bool operator > (const BSTR w, const WideString& rhs);
  bool operator <=(const BSTR w, const WideString& rhs);
  bool operator >=(const BSTR w, const WideString& rhs);
#else  
  bool operator ==(const char16_t* w, const WideString& rhs);
  bool operator !=(const char16_t* w, const WideString& rhs);
  bool operator < (const char16_t* w, const WideString& rhs);
  bool operator > (const char16_t* w, const WideString& rhs);
  bool operator <=(const char16_t* w, const WideString& rhs);
  bool operator >=(const char16_t* w, const WideString& rhs);
#endif

#else
  // In NEXTGEN mode there's no WideString but System.hpp still leaks the type
  // So we provide a dummy/unusable version here to compiler System.hpp
  class RTL_DELPHIRETURN WideString
  {
    WideString();
   ~WideString();   
    WideString(const WideString& src);
    WideString& operator=(const WideString& rhs); 
    WideChar* Data;
  };
#endif

}

#pragma delphiheader end.

#endif




