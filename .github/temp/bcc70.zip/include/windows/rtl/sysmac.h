// -----------------------------------------------------------------------------------
// SYSMAC.H: Generic macros and forward declarations of core Delphi types
//
// $Rev: 78183 $
//
// Copyright(c) 1995-2011 Embarcadero Technologies, Inc.
// -----------------------------------------------------------------------------------
#if !defined(SYSMAC_H)
#define SYSMAC_H

#if !defined(SystemHPP)
#error Do not include this file directly.  Include 'System.hpp'.
#endif
#if !defined(__cplusplus)
#error sysmac.h cannot be used in C mode - this header requires C++!
#endif


#if !defined(__RTL_BUILD__) && !defined(NO_LINK_VCLE) && !defined(NO_LINK_RTLE)
  #if defined(_Windows) && !defined(_WIN64)
    #if defined(__clang__)
      #pragma comment(lib, "rtle.lib")
    #else
      #pragma comment(lib, "vcle.lib")
    #endif
  #endif
  #if defined(__APPLE__)
    #pragma comment(lib, "rtle.a")
  #endif
  #if defined(_WIN64)
    #pragma link "rtle.a"
    #if defined(NO_STRICT)
      // Usage of NO_STRICT will result in unresolved symbols due to mangling mismatches
      // See http://docwiki.embarcadero.com/RADStudio/XE3/en/C%2B%2B_Applications_Use_STRICT_Type_Checking
      #error "NO_STRICT was defined. Usage of the Delphi runtime requires STRICT mangling"
      #error "Please see 'http://docwiki.embarcadero.com/RADStudio/XE3/en/C%2B%2B_Applications_Use_STRICT_Type_Checking'"
    #endif
  #endif
#endif

#if defined(__BORLANDC__) && (__BORLANDC__ < 0x500)
#error BCW 5.0 or greater required
#endif

// Starting with v2011 STRINGCHECKS are disabled.
// See http://blogs.embarcadero.com/abauer/2010/01/26/38908
#define _STRINGCHECKS_OFF


#if !defined(_Windows)

  #if defined(__APPLE__)
    #if !defined(__clang__)
      // Header /usr/include/TargetConditionals.h expects a TARGET_CPU to be defined
      // (Should be defined by RTL headers ??)
      #define TARGET_CPU_X86 1
      #define TARGET_OS_MAC  1

      // To circumvent that header - as it causes us grief
      // (Should be handled by RTL headers ??)
      #define _OS_OSBYTEORDERMACHINE_H
      #define OS_INLINE inline

      // On Mac /usr/include\i386/_types.h will define wint_t before _stddef.h causing
      // errors when the latter assumes wint_t is in the std namespace
      // (Should be handled by RTL headers ??)
      #include <_stddef.h>
    #else
      #include "TargetConditionals.h"
    #endif

    #if defined(TARGET_OS_IPHONE) || defined(TARGET_IPHONE_SIMULATOR)
      #include <stdio.h>
    #endif

    // The Delphi RTL requires CoreFoundation and CoreServices
    #include <CoreFoundation/CoreFoundation.h>

    #if !defined(TARGET_OS_IPHONE) && !defined(TARGET_IPHONE_SIMULATOR)
      #pragma option push -w-8017  // Workaround redefinition of NSEC_PER_USEC and USEC_PER_SEC
      #include <CoreServices/CoreServices.h>
      #pragma option pop
      #include <Carbon/Carbon.h>
    #endif
  #endif
#endif

// Macros used by Designer
#if defined(_WIN32)
  #define _PLAT_MSWINDOWS
#elif defined(TARGET_OS_IPHONE) || defined(TARGET_IPHONE_SIMULATOR)
  #define _PLAT_IOS
  #if defined(__aarch64__)
    #define _PLAT_IOS64
  #elif defined(__arm__)
    #define _PLAT_IOS32
  #endif
#elif defined(TARGET_OS_MAC)
  #define _PLAT_MACOS
#elif defined(__ANDROID__)
  #define _PLAT_ANDROID
#else
  #error "Unknown Platform!"
#endif

#include <stdint.h>

#if defined(__clang__)
  #define NO_DI_DISAMBIGUATE_RELEASE //FIXME
#endif

#ifndef _Windows
  #include <signal.h> // For pthread_attr_t
  #include <fcntl.h>
  #include <string.h>
#endif


#ifdef _Windows
  // !! This is on now (Oops!)// NOTE: CLANG supports this as an ms-extension
  #pragma anon_struct on      // support anonymous structs (within unions)

  // Bring in Interface definitions - Supply what might be missing in LEAN_AND_MEAN mode
  //
  #if !defined(BEGIN_INTERFACE)       // If OBJBASE.H has not been seen yet!
  # define BEGIN_INTERFACE
  #endif
  #if !defined(END_INTERFACE)         // If OBJBASE.H has not been seen yet!
  # define END_INTERFACE
  #endif
  #if !defined(WINOLEAPI)             // If OBJBASE.H has not been seen yet!
  # define WINOLEAPI        EXTERN_C DECLSPEC_IMPORT HRESULT STDAPICALLTYPE
  #endif
  #if !defined(HUGEP)                 // If OBJBASE.H has not been seen yet!
  # define HUGEP
  #endif
  #if !defined(DECLARE_INTERFACE_IID_)
  # define DECLARE_INTERFACE_IID_(iface, baseiface, iid)   interface DECLSPEC_UUID(iid) DECLSPEC_NOVTABLE iface : public baseiface
  #endif

  #include <windows.h>
  #include <delayimp.h>


  #if !defined(_BASETYPS_H_)
  #include <basetyps.h>
  #endif
#endif // _Windows

#ifdef __linux__
  #define _GNU_SOURCE 1
  #include <pthread.h>
  #include <semaphore.h>
#endif

#define __safecall __stdcall
#define __interface struct
#define __dispinterface class

#if !defined(NO_MANAGED_INTERFACE_OPERATORS)
#define MANAGED_INTERFACE_OPERATORS
#endif

#if !defined(__UUID_SUPPORT__) && !defined(NO_UUID_SUPPORT_CHECK) && !defined(__clang__) // FIXME
  #error "System.hpp/sysmac.h and related headers need __declspec(uuid(..)) and __uuidof support"
#endif

#define INTERFACE_UUID(guid) __declspec(uuid(guid))  // For associating a GUID with a type


// Windows types needed for analogous pascal constructs
#if !defined(_WIN32) || defined(SYSMAC_WINDOWS_TYPES)
  #if !defined(STDMETHODCALLTYPE)
    #define STDMETHODCALLTYPE __stdcall
  #endif

  struct _GUID
  {
    uint32_t Data1;
    uint16_t Data2;
    uint16_t Data3;
    uint8_t  Data4[8];

    bool operator ==(const _GUID& other) const
    {
      return memcmp(this, &other, sizeof(*this)) == 0;
    }
  };

  typedef _GUID GUID;
  typedef _GUID IID;
  typedef _GUID UUID;
#if defined(__APPLE__) && (defined(__arm__) || defined(__arm64__)) || defined(__ANDROID__)
  // The Delphi RTL incorrectly relies on the fact that on Windows const of a
  // particular size and for certain calling convention are passed indirectly.
  // So const is used to describe the IID parameter of QueryInterface. On iOS,
  // this causes a problem as dcciosarm does not mangle the parameter as ref.
  // This leaves C++ with a problem:
  //  # Use IID& and have mangling mismatches with Delphi, or
  //  # Use plain IID to avoid mangling mismatches but have ABI incompatibility
  //    with Windows code.
  // As a way to ease the problem, we will define REFIID as a non-ref _GUID
  // to ease the transition. And ask the Delphi RTL team to use [ref] and not
  // rely on Windows-specific internal details of const.
  typedef const _GUID  REFIID;
#else
  typedef const _GUID& REFIID;
#endif

 #ifndef _HRESULT_DEFINED
  //TODO: HRESULT is a strong alias with NEXTGEN
  typedef uint32_t HRESULT;
  #define _HRESULT_DEFINED
 #endif

  // typedefs that come from windef.h on Windows but are used by IDE's Code Manager
  // So in order to support existing event signatures on OS/X, we'll define these
 #ifndef _BYTE_DEFINED
  #define _BYTE_DEFINED
  typedef unsigned char   BYTE;
 #endif
 #ifndef _WORD_DEFINED
  #define _WORD_DEFINED
  typedef unsigned short  WORD;
 #endif 
 #ifndef _DWORD_DEFINED
  #define _DWORD_DEFINED 
  typedef unsigned long   DWORD;
 #endif
 #ifndef _ULONG_DEFINED
  #define _ULONG_DEFINED
  typedef unsigned int    ULONG;
 #endif
 #ifndef _LONG_DEFINED
  #define _LONG_DEFINED
  typedef int             LONG;
 #endif
 #ifndef _UINT_DEFINED
  #define _UINT_DEFINED
  typedef unsigned int    UINT;
 #endif
 #ifndef _BOOL_DEFINED
  #define _BOOL_DEFINED
  typedef int             BOOL;
 #endif

  struct POINT
  {
    int32_t x;
    int32_t y;
  };

  struct POINTF
  {
    float x;
    float y;
  };

  struct RECT
  {
    int32_t left;
    int32_t top;
    int32_t right;
    int32_t bottom;
  };

  struct tagSIZE
  {
    int32_t cx;
    int32_t cy;
  };

  struct tagVECTOR{
    union{
      struct{
        float x;
        float y;
        float w;
      };
      float v[3];
    };
  };

  struct tagMATRIX{
    union{
      struct{
        float m11, m12, m13;
        float m21, m22, m23;
        float m31, m32, m33;
      };
      tagVECTOR m[3];
    };
  };

  struct tagPOINT3D{
    float x;
    float y;
    float z;
  };

  struct tagVECTOR3D{
    union{
      struct{
        float x;
        float y;
        float z;
        float w;
      };
      float v[4];
    };
  };

  struct tagMATRIX3D{
    union{
      struct{
        float m11, m12, m13, m14;
        float m21, m22, m23, m24;
        float m31, m32, m33, m34;
        float m41, m42, m43, m44;
      };
      tagVECTOR3D m[4];
    };
  };

  // Intentionally left in the global namespace
  struct INTERFACE_UUID("00000000-0000-0000-C000-000000000046") IUnknown {
    virtual HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void ** ppvObject) = 0;
    virtual ULONG   STDMETHODCALLTYPE AddRef() = 0;
    virtual ULONG   STDMETHODCALLTYPE Release() = 0;
  };
  typedef IUnknown* LPUNKNOWN;
  #define __unknwn_h__ __FILE__

#endif // !_WIN32 || SYSMAC_WINDOWS_TYPES

#if defined(_WIN64)
  #define PACKAGE            __declspec(package)
  #define DELPHI_PACKAGE     __declspec(package)  // Implemented in Delphi Package
#elif defined(TARGET_OS_IPHONE) || defined(TARGET_IPHONE_SIMULATOR) || defined(__ANDROID__)
  #define PACKAGE
  #define DELPHI_PACKAGE     __declspec(package)  // Implemented in Delphi Package
#else
  #define PACKAGE            __declspec(package)
  #define DELPHI_PACKAGE     __declspec(package)  // Implemented in Delphi Package
#endif

#ifdef __linux__
  #undef PACKAGE
  #define PACKAGE
#endif

#if defined(TARGET_OS_IPHONE) || defined(TARGET_IPHONE_SIMULATOR) || defined(__ANDROID__)
  #define DELPHIRETURN         __declspec(delphireturn)                  // Uses Delphi's return semantic
  #define PASCALIMPLEMENTATION __declspec(pascalimplementation)          // Implemented in Delphi - no code should be generated
  #define DELPHICLASS          __declspec(delphiclass)                   // Delphi-style class (derives from TObject)
  #define _DELPHICLASS_TOBJECT __declspec(delphiclass, pascalimplementation)
#else
  #define DELPHIRETURN         __declspec(delphireturn, package)         // Uses Delphi's return semantic; may reside in a package
  #define PASCALIMPLEMENTATION __declspec(pascalimplementation, package) // Implemented in Delphi - no code should be generated; may reside in a package
  #define DELPHICLASS          __declspec(delphiclass, package)          // Delphi-style class (derives from TObject); may reside in a package
  #define _DELPHICLASS_TOBJECT __declspec(delphiclass, pascalimplementation, package)
#endif

#define DYNAMIC              __declspec(dynamic)                       // For compatibility with Delphi's old virtual mechanism
// Delphi threadvar
#if defined(__clang__)
  #if defined(_WIN64) || __has_feature(tls)
    #define DELPHITHREAD     __declspec(thread)
  #else
    #define DELPHITHREAD
  #endif
#else
  #define DELPHITHREAD      __declspec(thread)
#endif

// Macros specifically for C++ emulation of Delphi language features
// Used for RTL functionality which should not be packaged.
//
#define RTL_DELPHIRETURN     __declspec(delphireturn)           // Uses Delphi's return semantic (not in package)
#define RTL_DELPHICLASS      __declspec(delphiclass)            // Implemented in Delphi

#define HIDESBASEDYNAMIC     __declspec(hidesbase, dynamic)     // For compatibility with Delphi
#define HIDESBASE            __declspec(hidesbase)              // For compatibility with Delphi

#if !defined(MESSAGE)
#define MESSAGE
#endif

#if !defined(__typeinfo)          // Use with TObject-derived classes
  #if !defined(BCC32_HAS_CLASSMETHODS)
    #define __typeinfo(type)  (PTypeInfo)TObject::ClassInfo(__classid(type))
  #else
    #define __typeinfo(type)  (PTypeInfo)type::ClassInfo()
  #endif
#endif
#if !defined(__arrayTypeinfo)     // Use with DynamicArray<T> types
#define __arrayTypeinfo(type)  __delphirtti(type)
#endif
#if !defined(__interfaceTypeinfo) // Use with interfaces that have DECLSPEC_RTTI
#define __interfaceTypeinfo(type)  __delphirtti(type)
#endif

// Noop Macro to tag open array parameters: used by IDE's Code Manager
#define _ARRAYOF

#if (__BORLANDC__ < 0x0560)
#define DECLSPEC_DRTTI
#else
#define DECLSPEC_DRTTI       __declspec(delphirtti)   // Emit interface RTTI (or when enabled on a __declspec(delphiclass)
                                                      // type, generate rich method RTTI for public & published method
#endif

#ifdef _WIN64
 #if defined(USEPACKAGES)
  #define DECLSPEC_DRECORD   __declspec(delphirecord, dllimport)
 #else
  #define DECLSPEC_DRECORD   __declspec(delphirecord)
 #endif
 #define DECLSPEC_DENUM      __declspec(delphienum)
#else
 #if defined(__arm__) || defined(__arm64__)
  #define DECLSPEC_DRECORD    __declspec(delphirecord) // VALIDATE
  #define DECLSPEC_DENUM
 #else
  #define DECLSPEC_DRECORD    __declspec(delphirecord, dllimport)
  #define DECLSPEC_DENUM
 #endif
#endif

#if defined(_DELPHI_AUTOREFCOUNT)
 #define DELPHI_AUTOREFCOUNT
#endif

// Delphi Mobile/NextGen uses 0-based strings. However, C++
// code may define _DELPHI_STRING_ONE_BASED when porting/using
// Desktop code in a Mobile project to keep 1-based indices
#if defined(_DELPHI_NEXTGEN)
  #if !defined(_DELPHI_STRING_ONE_BASED)
    #define _DELPHI_STRING_ZERO_BASED
  #endif
#else
  #define _DELPHI_STRING_ONE_BASED
#endif

// CLANG vs. BCC attributes
#if !defined(__clang__)
#define _FINAL_ATTRIBUTE              [[final]]
#define _DEPRECATED_ATTRIBUTE0        [[deprecated]]
#define _DEPRECATED_ATTRIBUTE1(msg)   [[deprecated]]  // Ignore message as bcc's implementation is capped:(
#define _DEPRECATED_ATTRIBUTE2        [[deprecated]]
#define _DEPRECATED_ATTRIBUTE3(msg)   [[deprecated]]  // Ignore message as bcc's implementation is capped:(
#define _ANNOT_ATTR_NC
#define _ALWAYS_INLINE
#define DRECORD_ALIGNAS(x)
#else
#define _FINAL_ATTRIBUTE
#define _DEPRECATED_ATTRIBUTE0        // Could use __attribute__((deprecated))
#define _DEPRECATED_ATTRIBUTE1(msg)   // Could use __attribute__((deprecated( msg )))
#define _DEPRECATED_ATTRIBUTE2        __attribute__((deprecated))
#define _DEPRECATED_ATTRIBUTE3(msg)   __attribute__((deprecated( msg )))
#define _ANNOT_ATTR_NC                __attribute__((annotate("nc")))
#define _ALWAYS_INLINE                __attribute__((__always_inline__))
#define DRECORD_ALIGNAS(x)            alignas(x)
#endif

#define BEGIN_MESSAGE_MAP   virtual void __fastcall Dispatch(void *Message) \
        {                                           \
          switch  (((PMessage)Message)->Msg)        \
          {

#define VCL_MESSAGE_HANDLER(msg,type,meth)          \
          case    msg:                              \
            meth(*((type *)Message));               \
            break;

// NOTE: ATL defines a MESSAGE_HANDLER macro which conflicts with VCL's macro. The
//       VCL macro has been renamed to VCL_MESSAGE_HANDLER. If you are not using ATL,
//       MESSAGE_HANDLER is defined as in previous versions of BCB.
//
#if !defined(USING_ATL) && !defined(USING_ATLVCL) && !defined(INC_ATL_HEADERS)
#define MESSAGE_HANDLER  VCL_MESSAGE_HANDLER
#endif // ATL_COMPAT

#define END_MESSAGE_MAP(base)           default:    \
                        base::Dispatch(Message);    \
                        break;                      \
          }                                         \
        }

#if defined(_Windows) && !defined(__unknwn_h__)
#include <unknwn.h>
#endif

#if !defined(__clang__)
 #if sizeof(wchar_t) == 2
  #define WIDECHAR_IS_WCHAR
 #elif sizeof(wchar_t) == 4
  #define WIDECHAR_IS_CHAR16
 #else
  #error unsupported wchar_t
 #endif
#else
 #if defined(_WIN32)
  #define WIDECHAR_IS_WCHAR
 #elif defined(__APPLE__) || defined(__ANDROID__)
  #define WIDECHAR_IS_CHAR16
 #else
  #error unsupported wchar_t
 #endif
#endif

namespace System
{
    class _DELPHICLASS_TOBJECT TObject;
    class DELPHICLASS TInterfacedObject;

    class   TMetaClass;
    typedef TMetaClass* TClass;

    template <typename ALIAS_T>
    class DelphiMetaClass
    {
    protected:
      typedef DelphiMetaClass<ALIAS_T> DelphiMetaType;
      DelphiMetaClass()
      {}
      DelphiMetaClass(System::TMetaClass* p) : data(p)
      {}
    public:
      operator System::TMetaClass* () {
        return this->data;
      }
      System::TMetaClass* operator->() {
        return this->data;
      }
    private:
      System::TMetaClass* data;
    };

#if !defined(__clang__)
 #define _DECLARE_METACLASS(Base, Meta) typedef Base Meta;
#else
 #define _DECLARE_METACLASS(Base, Meta)                  \
  class Meta : public System::DelphiMetaClass<Meta> {    \
  public:                                                \
    Meta()                     : DelphiMetaType() {}     \
    Meta(System::TMetaClass* p): DelphiMetaType(p){}     \
  }
#endif

#if defined(DELPHI_AUTOREFCOUNT)
  #ifndef __clang__
    #define __weak
    #define __unsafe
    #define __strong
  #else
    #define __unsafe  __attribute__((borland_arc(borland_unsafe)))
  #endif
#else
  #define __weak
  #define __unsafe
  #define __strong
#endif


#if defined(ANSISTRING_AS_TEMPLATE)
    class RTL_DELPHIRETURN AnsiStringBase;
    template <unsigned short CP> class RTL_DELPHIRETURN AnsiStringT;
    typedef  AnsiStringT<0> AnsiString;
  #if defined(_DELPHI_NEXTGEN)
    typedef AnsiStringT<65001> UTF8String;
    typedef AnsiStringT<65535> RawByteString;
    typedef RawByteString* PRawByteString;
  #endif
#else
    class RTL_DELPHIRETURN AnsiString;
#endif
    class RTL_DELPHIRETURN WideString;
    class RTL_DELPHIRETURN UnicodeString;

    template <unsigned char sz> class SmallStringBase;
    template <unsigned char sz> class SmallString;

    class RTL_DELPHIRETURN CurrencyBase;
    class RTL_DELPHIRETURN Currency;

    class RTL_DELPHIRETURN OleVariant;
    class RTL_DELPHIRETURN Variant;

    struct PACKAGE TLibModule;
    struct PACKAGE TModuleUnloadRec;

    struct PACKAGE THeapStatus;
    struct PACKAGE TMemoryManager;
    struct PACKAGE TMemoryManagerEx;

    struct PACKAGE TVariantManager;
    /* class PACKAGE TDynArrayTypeInfo; */

    template<class T> class RTL_DELPHIRETURN DynamicArray;

    class RTL_DELPHIRETURN TDateTimeBase;
    class RTL_DELPHIRETURN TDateTime;

    struct        CompBase;
    struct        Comp;

    struct PACKAGE TLibModule;
    typedef TLibModule *PLibModule;

    struct PACKAGE TResStringRec;
    typedef TResStringRec *PResStringRec;

#if !defined(__clang__)
  #define SET_BOUNDS_UNSIGNED_CHAR
#endif

#if defined(SET_BOUNDS_UNSIGNED_CHAR)
  #define _DELPHI_SET_CHAR(x)           x
  #define _DELPHI_SET_ENUMERATOR(x)     static_cast<unsigned char>(x)
#else
  #define _DELPHI_SET_CHAR(x)           char(x)
  #define _DELPHI_SET_ENUMERATOR(x)     x
#endif

    template<class T, unsigned char minEl, unsigned char maxEl> class RTL_DELPHIRETURN SetBase;
#if defined(__clang__) || !defined(SET_BOUNDS_UNSIGNED_CHAR)
    template<class T, T minEl, T maxEl> class RTL_DELPHIRETURN Set;
#else
    template<class T, unsigned char minEl, unsigned char maxEl> class RTL_DELPHIRETURN Set;
#endif

    // Helper template used for when Delphi functions
    //  - return static arrays
    //  - expect static array parameters
    // The HPP generator uses StaticArray<type, size> in these cases
    // since C++ decays array parameters (hence would break on overload)
    // and cannot have a return type of type array.
    template <typename T, int size> struct StaticArray
    {
      T data[size];

      int Size() const { return size; };

      const T& operator[](int index) const { return data[index]; }
      T& operator[](int index) { return data[index]; }

      operator const T*() const { return data; }
      operator T*() { return data; }
    };

    // NOTE: OSX' "/usr/include/MacTypes.h" declares Boolean as 'unsigned char' :(
#ifndef NO_SYSTEM_BOOLEAN
    typedef bool                 Boolean;          //
#endif
    typedef int                  Integer;          // -2147483648..2147483647
#if defined(WIDECHAR_IS_WCHAR)
    typedef wchar_t              WideChar;         // Unicode character
#else
    typedef char16_t             WideChar;
#endif

#if 1
    // Shortint is a source of confusion for C++ where Short implies, well, short!!
    typedef signed char          Shortint _DEPRECATED_ATTRIBUTE0;         // -128..127
    typedef signed char          ShortInt _DEPRECATED_ATTRIBUTE0;         // -128..127
    //typedef Shortint*            PShortint;        //
#endif
    typedef signed char          Int8;             // -128..127
    typedef short                Smallint;         // -32768..32767
    typedef unsigned char        Byte;             // 0..255
    typedef unsigned short       Word;             // 0..65535
    typedef unsigned long        DWord;            // 0..4294967295
#if defined(_PLAT_IOS64)
    typedef unsigned long        LongWord;         // 0..18446744073709551615
#elif defined(_PLAT_IOS32)
    typedef unsigned /*long*/    LongWord;         // 0..4294967295
#else
    typedef unsigned             LongWord;         // 0..4294967295
#endif
    typedef void*                Pointer;          //
    typedef Pointer*             PPointer;         //
    typedef char                 AnsiChar;         //
#if defined(_PLAT_IOS64)
    typedef long                 Longint;          // -9223372036854775808..9223372036854775807
#elif defined(_PLAT_IOS32)
    typedef int /*long*/         Longint;          // --2147483648..2147483647
#else
    typedef int                  Longint;          // -2147483648..2147483647
#endif
    typedef signed __int64       Largeint;         //
    typedef unsigned int         Cardinal;         // 0..4294967295
    typedef long double          Extended;         // 10 byte real
    typedef float                Single;           // 4 byte real
    typedef Single*              PSingle;          //
    typedef double               Double;           // 8 byte real
    typedef char* const          Openstring;       // D16 string/D32 shortstring formalparm
    typedef void*                file;             //
#if defined(_PLAT_IOS64) || defined(_WIN64)
    // Size:754, Align:8
    typedef struct {
      void* p1[94];
      char  p2[2];
    } TextFile;
#else
    // Size:730, Align:4
    typedef struct {
      void* p1[182];
      char  p2[2];
    } TextFile;
#endif
    typedef char*                PAnsiChar;        //
    typedef WideChar*            PWideChar;        //
    // Uppercase 'C' 'Char' maps to Delphi's native 'char'
    // type for backward compatibility. To avoid confusion
    // of 'char' and 'Char', it's best to use _DCHAR
#if defined(_DELPHI_STRING_UNICODE)
    typedef WideChar             Char;
    typedef PWideChar            PChar;            //
    typedef WideChar             _DCHAR;
  #if defined(WIDECHAR_IS_WCHAR)
    #define _D(__s)              L ## __s
  #else
    #define _D(__s)              u ## __s
  #endif
#else
    typedef char                 Char;             // 0..255
    typedef PAnsiChar            PChar;            //
    typedef char                 _DCHAR;
    #define _D(__s)              __s
#endif

    // Forward ref. for QI of IInterface
    template <class T> class RTL_DELPHIRETURN DelphiInterface;

#if defined(_DELPHI_NEXTGEN) && !defined(_Windows)
	static constexpr System::Int8 S_OK = System::Int8(0x0);
	static constexpr System::Int8 S_FALSE = System::Int8(0x1);
#endif

    // NOTE: IInterface is really IUnknown - with the same UUID - resolves the mangling issues
    // we've been having in COM stuff
    __interface INTERFACE_UUID("00000000-0000-0000-C000-000000000046") IInterface : public IUnknown
    {
    public:
      /** Template function to ease querying for a smart-Interface-object */
      template <typename T>
      bool /*__stdcall*/ Supports(DelphiInterface<T>& smartIntf)
      {
        return QueryInterface(__uuidof(T), reinterpret_cast<void**>(static_cast<T**>(&smartIntf))) == S_OK;
      }
    };

    // Base type from which SOAP remotable interfaces derive.
    // It triggers the compiler to generate RTTI for the
    // methods and their parameters. This information is then
    // used to expose the interface as SOAP ports/operations.
    //
    // NOTE: IInvokable is really IInterface/IUnknown - with the same UUID - with __declspec(delphirtti)
    __interface INTERFACE_UUID("00000000-0000-0000-C000-000000000046") DECLSPEC_DRTTI IInvokable : public IInterface
    {};

    // Earlier versions of Delphi mapped built-in types such as NativeInt/NativeUInt
    // ByteBool/WordBool/LongBool to C++ built-in types. But that prevented Delphi
    // code from overloading on, say, NativeInt and Integer (they both had to mangle
    // to 'int'). Newer versions of Delphi mangle these types as strong aliases.
    // To be compatible with the change, C++ will also create strong aliases.
    // This, though, comes at a cost: to avoid ambiguity, conversions must be explicit.
    // For example:
    //      NativeInt ni = 100;                  // Error
    //      NativeInt ni = NativeInt(100);       // OK
    //      System::GetMemory(0x100);            // Error
    //      System::GetMemory(NativeInt(0x100)); // OK
    template <typename BASE_T, typename ALIAS_T>
    class AliasT
    {
    protected:
      typedef AliasT<BASE_T, ALIAS_T> AliasType;
      AliasT() : data(BASE_T())
      {}
#ifdef __clang__
      constexpr
#endif
#ifndef _ALIAST_EXPLICIT_CONSTRUCTOR
      explicit
#endif
      AliasT(const BASE_T &p) : data(p)
      {}
    public:
      const BASE_T& get() const
      {
        return data;
      }
      BASE_T& get()
      {
        return data;
      }
      // postfix ++ --
      friend ALIAS_T operator++(ALIAS_T &p, int)
      {
        ALIAS_T result(p.data);
        p.data++;
        return result;
      }
      friend ALIAS_T operator--(ALIAS_T &p, int)
      {
        ALIAS_T result(p.data);
        p.data--;
        return result;
      }
      // unary (prefix) ++ -- ~ !
      friend ALIAS_T operator++(ALIAS_T &p)
      {
        p.data++;
        return p;
      }
      friend ALIAS_T operator--(ALIAS_T &p)
      {
        p.data--;
        return p;
      }
      friend ALIAS_T operator~(const ALIAS_T &p)
      {
        return ALIAS_T(~p.data);
      }
      friend ALIAS_T operator!(const ALIAS_T &p)
      {
        return ALIAS_T(!p.data);
      }
      // &
      friend const BASE_T* operator&(const ALIAS_T &p)
      {
        return &p.data;
      }
      friend BASE_T* operator&(ALIAS_T &p)
      {
        return &p.data;
      }
      // multiplicative * / %
      friend ALIAS_T operator*(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data * p.data);
      }
      friend ALIAS_T operator*(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data * v);
      }
      friend ALIAS_T operator*(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data * v);
      }
      friend ALIAS_T operator/(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data / p.data);
      }
      friend ALIAS_T operator/(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data / v);
      }
      friend ALIAS_T operator/(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data / v);
      }
      friend ALIAS_T operator%(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data % p.data);
      }
      friend ALIAS_T operator%(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data % v);
      }
      friend ALIAS_T operator%(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data % v);
      }
      // additive + -
      friend ALIAS_T operator+(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data + p.data);
      }
      friend ALIAS_T operator+(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data + v);
      }
      friend ALIAS_T operator+(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data + v);
      }
      friend ALIAS_T operator-(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data - p.data);
      }
      friend ALIAS_T operator-(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data - v);
      }
      friend ALIAS_T operator-(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data - v);
      }
      // shift << >>
      friend ALIAS_T operator>>(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data >> p.data);
      }
      friend ALIAS_T operator>>(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data >> v);
      }
      friend ALIAS_T operator>>(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data >> v);
      }
      friend ALIAS_T operator<<(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data << p.data);
      }
      friend ALIAS_T operator<<(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data << v);
      }
      friend ALIAS_T operator<<(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data << v);
      }
      // relational < > <= >=
      friend bool operator<(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return (p.data < p.data);
      }
      friend bool operator<(const ALIAS_T &p, const BASE_T& v)
      {
        return (p.data < v);
      }
      friend bool operator<(const BASE_T& v, const ALIAS_T &p)
      {
        return (p.data < v);
      }
      friend bool operator>(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return (p.data > p.data);
      }
      friend bool operator>(const ALIAS_T &p, const BASE_T& v)
      {
        return (p.data > v);
      }
      friend bool operator>(const BASE_T& v, const ALIAS_T &p)
      {
        return (p.data > v);
      }
      friend bool operator<=(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return (p.data <= p.data);
      }
      friend bool operator<=(const ALIAS_T &p, const BASE_T& v)
      {
        return (p.data <= v);
      }
      friend bool operator<=(const BASE_T& v, const ALIAS_T &p)
      {
        return (p.data <= v);
      }
      friend bool operator>=(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return (p.data >= p.data);
      }
      friend bool operator>=(const ALIAS_T &p, const BASE_T& v)
      {
        return (p.data >= v);
      }
      friend bool operator>=(const BASE_T& v, const ALIAS_T &p)
      {
        return (p.data >= v);
      }
      // equality == !=
      friend bool operator==(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return (p.data == p.data);
      }
      friend bool operator==(const ALIAS_T &p, const BASE_T& v)
      {
        return (p.data == v);
      }
      friend bool operator==(const BASE_T& v, const ALIAS_T &p)
      {
        return (p.data == v);
      }
      friend bool operator!=(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return (p.data != p.data);
      }
      friend bool operator!=(const ALIAS_T &p, const BASE_T& v)
      {
        return (p.data != v);
      }
      friend bool operator!=(const BASE_T& v, const ALIAS_T &p)
      {
        return (p.data != v);
      }
      // bitwise AND &
      friend ALIAS_T operator&(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data & p.data);
      }
      friend ALIAS_T operator&(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data & v);
      }
      friend ALIAS_T operator&(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data & v);
      }
      // bitwise XOR ^
      friend ALIAS_T operator^(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data ^ p.data);
      }
      friend ALIAS_T operator^(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data ^ v);
      }
      friend ALIAS_T operator^(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data ^ v);
      }
      // bitwise OR |
      friend ALIAS_T operator|(const ALIAS_T &p, const ALIAS_T &p2)
      {
        return ALIAS_T(p.data | p.data);
      }
      friend ALIAS_T operator|(const ALIAS_T &p, const BASE_T& v)
      {
        return ALIAS_T(p.data | v);
      }
      friend ALIAS_T operator|(const BASE_T& v, const ALIAS_T &p)
      {
        return ALIAS_T(p.data | v);
      }
      // assignment *= /= %= += -= >>= <<= &= ^= |=
      friend const ALIAS_T& operator*=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data *= p2.data;
        return p;
      }
      friend const ALIAS_T& operator*=(ALIAS_T &p, const BASE_T& v)
      {
        p.data *= v;
        return p;
      }
      friend const ALIAS_T& operator/=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data /= p2.data;
        return p;
      }
      friend const ALIAS_T& operator/=(ALIAS_T &p, const BASE_T& v)
      {
        p.data /= v;
        return p;
      }
      friend const ALIAS_T& operator%=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data %= p2.data;
        return p;
      }
      friend const ALIAS_T& operator%=(ALIAS_T &p, const BASE_T& v)
      {
        p.data %= v;
        return p;
      }
      friend const ALIAS_T& operator+=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data += p2.data;
        return p;
      }
      friend const ALIAS_T& operator+=(ALIAS_T &p, const BASE_T& v)
      {
        p.data += v;
        return p;
      }
      friend const ALIAS_T& operator-=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data -= p2.data;
        return p;
      }
      friend const ALIAS_T& operator-=(ALIAS_T &p, const BASE_T& v)
      {
        p.data -= v;
        return p;
      }
      friend const ALIAS_T& operator>>=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data >>= p2.data;
        return p;
      }
      friend const ALIAS_T& operator>>=(ALIAS_T &p, const BASE_T& v)
      {
        p.data >>= v;
        return p;
      }
      friend const ALIAS_T& operator<<=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data <<= p2.data;
        return p;
      }
      friend const ALIAS_T& operator<<=(ALIAS_T &p, const BASE_T& v)
      {
        p.data <<= v;
        return p;
      }
      friend const ALIAS_T& operator&=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data &= p2.data;
        return p;
      }
      friend const ALIAS_T& operator&=(ALIAS_T &p, const BASE_T& v)
      {
        p.data &= v;
        return p;
      }
      friend const ALIAS_T& operator^=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data ^= p2.data;
        return p;
      }
      friend const ALIAS_T& operator^=(ALIAS_T &p, const BASE_T& v)
      {
        p.data ^= v;
        return p;
      }
      friend const ALIAS_T& operator|=(ALIAS_T &p, const ALIAS_T &p2)
      {
        p.data |= p2.data;
        return p;
      }
      friend const ALIAS_T& operator|=(ALIAS_T &p, const BASE_T& v)
      {
        p.data |= v;
        return p;
      }
  #if !defined(NO_ALIAST_CONVERSION_OPERATOR)
      /* explicit */ operator BASE_T() const {
        return data;
      }
  #endif
  #if !defined(NO_ALIAST_ASSIGNMENT_OPERATOR)
      AliasT& operator=(const BASE_T& rhs) {
        data = rhs;
        return *this;
      }
  #endif
    private:
      BASE_T data;
    };
}

#if defined(_DELPHI_NEXTGEN) && !defined(_Windows)

#define _DECLARE_ARITH_TYPE_ALIAS(Base, Alias)        \
  class Alias : public System::AliasT<Base, Alias> {  \
  public:                                             \
    Alias() : AliasType()                             \
    {}                                                \
    constexpr Alias(Base i) : AliasType(i)            \
    {}                                                \
    Alias& operator=(const Base &rhs) {               \
      AliasType::get() = rhs;                         \
      return *this;                                   \
    }                                                 \
  };

  // When mangled as strong aliases, Native[U]Int is[are] not in the System namespace :(
#if defined(_PLAT_IOS64)
  _DECLARE_ARITH_TYPE_ALIAS(long, NativeInt);
  _DECLARE_ARITH_TYPE_ALIAS(unsigned long, NativeUInt);
#else
  _DECLARE_ARITH_TYPE_ALIAS(int, NativeInt);
  _DECLARE_ARITH_TYPE_ALIAS(unsigned, NativeUInt);
#endif

#define _DECLARE_STRING_TYPE_ALIAS(Base, Alias) \
  class Alias : public Base {                   \
  public:                                       \
    Alias()                     : Base() {}     \
    Alias(const Base&  src)     : Base(src) {}  \
    Alias(const Alias& src)     : Base(src) {}  \
    Alias(const char* src)      : Base(src) {}  \
    Alias(const WideChar* src, int len) : Base(src, len) {} \
    Alias(const char* src, int len)     : Base(src, len) {} \
    Alias(const WideChar* src)          : Base(src) {}      \
    Alias(const char32_t* src, int numChar32 = -1) : Base(src, numChar32) {} \
    Alias(const wchar_t* src, int len = -1) : Base(src, len) {}              \
    Alias(char src)             : Base(src) {} \
    Alias(wchar_t src)          : Base(src) {} \
    Alias(short src)            : Base(src) {} \
    Alias(unsigned short src)   : Base(src) {} \
    Alias(int src)              : Base(src) {} \
    Alias(unsigned int src)     : Base(src) {} \
    Alias(long src)             : Base(src) {} \
    Alias(unsigned long src)    : Base(src) {} \
    Alias(__int64 src)          : Base(src) {} \
    Alias(unsigned __int64 src) : Base(src) {} \
    Alias(double src)           : Base(src) {} \
    ~Alias() {}                                \
  };

  namespace System
  {
    typedef unsigned char        ByteBool;         //
    typedef unsigned short       WordBool;         //
    typedef int                  LongBool;         //
  }
#endif

namespace System
{

#if !defined(_DELPHI_NEXTGEN) || defined(_Windows)
    typedef unsigned char        ByteBool;         //
    typedef unsigned short       WordBool;         //
    typedef int                  LongBool;         //
  #ifdef _WIN64
    typedef __int64              NativeInt;        //
    typedef unsigned __int64     NativeUInt;       //
  #else
    typedef int                  NativeInt;        //
    typedef unsigned int         NativeUInt;       //
  #endif
#endif

#if defined(_DELPHI_STRING_UNICODE)
    typedef UnicodeString        String;           //
#endif
#if !defined(_DELPHI_NEXTGEN)
    typedef SmallStringBase<255> ShortStringBase;  //
    typedef SmallString<255>     ShortString;      //
    typedef ShortString*         PShortString;     //
    typedef AnsiString*          PAnsiString;      //
#else
    typedef SmallStringBase<255> ShortStringBase;  //
    typedef SmallString<255>     ShortString;      //
    typedef ShortString*         PShortString;     //
    typedef AnsiString*          PAnsiString;      //
#endif
    typedef UnicodeString*       PUnicodeString;   //
#if defined(_DELPHI_STRING_UNICODE)
    typedef PUnicodeString       PString;          //
#else
    typedef PAnsiString          PString;          //
#endif
    typedef WideString*          PWideString;      //
    typedef Extended*            PExtended;        //
    typedef Currency*            PCurrency;        //
    typedef Variant*             PVariant;         //
    typedef OleVariant*          POleVariant;      //
    typedef GUID                 TGUID;            //
    typedef TGUID*               PGUID;            //
    typedef HRESULT              HResult;          //

    typedef Byte*                PByte;            //
    typedef Integer*             PInteger;         //
    typedef __int64*             PInt64;           //
    typedef LongWord*            PLongWord;        //
    typedef Smallint*            PSmallInt;        //
    typedef Boolean*             PBoolean;         //
    typedef PChar*               PPChar;           //
    typedef Double*              PDouble;          //
    typedef Cardinal             UCS4Char;         //
    typedef UCS4Char*            PUCS4Char;        //
    typedef DynamicArray<UCS4Char> UCS4String;     //

    typedef System::DelphiInterface<System::IInterface> _di_IInterface;

#ifdef __clang__
    extern const bool _init_inst;
#endif

#if defined(__ANDROID__)
    // System::_PPAnsiChar leaks via the PMarshaledAString alias
    typedef char**               _PPAnsiChar;
#endif

} // namespace System


#if defined(__ANDROID__)
 #define _INIT_UNIT(unitName)   \
  void initialization();        \
  void* __rstr_ ## unitName     \
        __attribute__((weak))   \
        __attribute__((used)) = reinterpret_cast<void*>(&initialization);
#else
 #define _INIT_UNIT(unitName)   \
  void initialization();        \
  void* __init_unit             \
        __attribute__((weak))   \
        __attribute__((used)) = reinterpret_cast<void*>(&initialization);
#endif

#if defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
    using System::TClass;
    using System::TMetaClass;
  #if !defined(_DELPHI_NEXTGEN) || defined(_Windows)
    using System::NativeInt;
    using System::NativeUInt;
  #endif
#endif

// Forward declaration to allow declaration of _di_IDispatch;
#if defined(_Windows)
__interface IDispatch;
typedef System::DelphiInterface<IDispatch> _di_IDispatch;
#endif
typedef System::DelphiInterface<IUnknown> _di_IUnknown;


// Forward ref. to satisfy prototypes in System.hpp
class TVarData;
typedef TVarData* PVarData;

#endif
