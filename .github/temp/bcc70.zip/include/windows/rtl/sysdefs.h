// SYSDEFS.H - Support for properties & vcl intrinsic types
// Copyright (c) 1997, 2002 Borland Software Corporation

#ifndef SYSDEFS_H
#define SYSDEFS_H
#pragma message "The SYSDEFS.H file should not be included; use System.hpp"
#include <system.hpp>
#endif

