/*  cio.h

    Standard C header file wrapper for io.h
*/

/*
 *      C/C++ Run Time Library - Version 22.0
 *
 *      Copyright (c) 1997, 2015 by Embarcadero Technologies, Inc.
 *      All Rights Reserved.
 *
 */

/* $Revision: 24271 $ */

#define  __USING_CNAME__
#include <io.h>
#undef   __USING_CNAME__
