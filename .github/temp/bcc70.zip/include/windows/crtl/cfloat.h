/*  cfloat.h

    Standard C header file wrapper for float.h
*/

/*
 *      C/C++ Run Time Library - Version 22.0
 *
 *      Copyright (c) 1997, 2015 by Embarcadero Technologies, Inc.
 *      All Rights Reserved.
 *
 */

/* $Revision: 23293 $ */

#define  __USING_CNAME__
#include <float.h>
#undef   __USING_CNAME__
