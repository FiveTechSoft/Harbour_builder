/* Memory.h - stub redirector for either mem.h
*/

/*
 *      C/C++ Run Time Library - Version 22.0
 *
 *      Copyright (c) 2002, 2015 by Embarcadero Technologies, Inc.
 *      All Rights Reserved.
 *
 */


#include <mem.h>
