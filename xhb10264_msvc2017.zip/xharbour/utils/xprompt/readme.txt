Please review utils\xbscript\xbscript.exe for the implementation
of the xPrompt Console application.

xPrompt is a fully functional, full featured, "DOt Prompt" Console
for the xHarbour Language.

The functionality of xPrompt is included in the utils\xbscript folder
because it is implemented in the same code base of xbScript which is
a full featured Interpreter of the xHarbour Langauge.
