/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2008190002
#define HB_VER_CHLID             "5080b9a46a6428dccd1824cc0b23f2a867d54e80"
#define HB_VER_LENTRY            "2020-08-19 02:02 UTC+0200 Przemyslaw Czerpak (druzus/at/poczta.onet.pl)"
#define HB_VER_HB_USER_PRGFLAGS  "-l-"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "msvc"
